import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

       
    // Lista para armazenar as pessoas cadastradas
    private static List<Pessoa> pessoas = new ArrayList<>();

    // Método para inserir dados de uma pessoa
    public static void cadastrarPessoa() {
        Scanner scanner = new Scanner(System.in);

        // Inserindo nome
        System.out.print("Digite o nome: ");
        String nome = scanner.nextLine();

        // Inserindo idade
        System.out.print("Digite a idade: ");
        int idade = scanner.nextInt();

        // Inserindo altura
        System.out.print("Digite a altura (em metros): ");
        double altura = scanner.nextDouble();

        // Limpando o buffer do scanner
        scanner.nextLine();  // Para capturar a próxima linha corretamente

        // Inserindo hobbies
        List<String> hobbies = new ArrayList<>();
        System.out.println("Digite os hobbies (digite 'sair' para terminar): ");
        while (true) {
            String hobby = scanner.nextLine();
            if (hobby.equalsIgnoreCase("sair")) {
                break;
            }
            hobbies.add(hobby);
        }

        // Criando uma nova pessoa e adicionando à lista
        Pessoa pessoa = new Pessoa(nome, idade, altura, hobbies);
        pessoas.add(pessoa);
        System.out.println("Pessoa cadastrada com sucesso!\n");
    }

    // Método para exibir todas as pessoas cadastradas
    public static void consultarPessoas() {
        if (pessoas.isEmpty()) {
            System.out.println("Nenhuma pessoa cadastrada.\n");
        } else {
            System.out.println("Pessoas cadastradas:");
            for (Pessoa pessoa : pessoas) {
                pessoa.exibirDados();
                System.out.println("------------------------");
            }
        }
    }

    // Método para excluir uma pessoa da lista
    public static void excluirPessoa() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome da pessoa que deseja excluir: ");
        String nome = scanner.nextLine();

        boolean encontrado = false;
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getNome().equalsIgnoreCase(nome)) {
                pessoas.remove(pessoa);
                System.out.println("Pessoa excluída com sucesso!\n");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Pessoa não encontrada.\n");
        }
    }

    // Menu principal para interagir com o usuário
    public static void exibirMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Cadastrar pessoa");
            System.out.println("2 - Consultar pessoas cadastradas");
            System.out.println("3 - Excluir pessoa");
            System.out.println("4 - Sair");
            System.out.print("Opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch (opcao) {
                case 1:
                    cadastrarPessoa();
                    break;
                case 2:
                    consultarPessoas();
                    break;
                case 3:
                    excluirPessoa();
                    break;
                case 4:
                    System.out.println("Saindo...");
                    return;
                default:
                    System.out.println("Opção inválida, tente novamente.");
            }
        }
    }

    public static void main(String[] args) {
        // Exibindo o menu de opções
        exibirMenu();
    }
}



    
    

