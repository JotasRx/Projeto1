
public class Principal {

    public static void main(String[] args) {
    
        Pessoa pessoa = new Pessoa("Jose", 25, 185, "futebol");
        
        pessoa.exibirDados();
        
    }   
}
