import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Coletando dados para cadastro
        System.out.print("Digite o nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a idade: ");
        int idade = scanner.nextInt();

        System.out.print("Digite a altura (em metros): ");
        double altura = scanner.nextDouble();

        // Limpando o buffer do scanner
        scanner.nextLine();

        // Coletando hobbies
        List<String> hobbies = new ArrayList<>();
        System.out.println("Digite os hobbies (digite 'sair' para terminar): ");
        while (true) {
            String hobby = scanner.nextLine();
            if (hobby.equalsIgnoreCase("sair")) {
                break;
            }
            hobbies.add(hobby);
        }

        // Criando uma instância de Pessoa
        Pessoa pessoa = new Pessoa(nome, idade, altura, hobbies);

        // Cadastrando a pessoa
        pessoa.cadastrar();

        // Exibindo os dados da pessoa
        pessoa.exibirDados();
    }
}

