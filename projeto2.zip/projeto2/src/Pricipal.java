import java.util.Scanner;

public class Pricipal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Coletando dados de um funcionário
        System.out.println("Cadastro de Funcionário");

        System.out.print("Digite o nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a idade: ");
        int idade = scanner.nextInt();

        System.out.print("Digite o salário: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); // Limpa o buffer

        System.out.print("Digite o cargo: ");
        String cargo = scanner.nextLine();

        // Criando uma instância de Funcionario (que é uma Pessoa com características adicionais)
        Funcionario funcionario = new Funcionario(nome, idade, salario, cargo);

        // Exibindo os dados do funcionário
        funcionario.exibirDados();
    }
}
