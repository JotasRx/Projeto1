public class Funcionario extends Pessoa {
    // Atributos específicos para um Funcionário
    private double salario;
    private String cargo;

    // Construtor da classe Funcionario
    public Funcionario(String nome, int idade, double salario, String cargo) {
        // Chama o construtor da classe base (Pessoa)
        super(nome, idade);
        this.salario = salario;
        this.cargo = cargo;
    }

    // Métodos getters e setters
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    // Sobrescrevendo o método exibirDados para incluir informações adicionais do Funcionario
    @Override
    public void exibirDados() {
        // Chama o método exibirDados da classe Pessoa
        super.exibirDados();
        System.out.println("Salário: " + salario);
        System.out.println("Cargo: " + cargo);
    }
}
